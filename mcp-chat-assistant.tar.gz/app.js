let mcpUrl = '';
let currentIssueKey = '';
let connected = false;

// Initialize when page loads
AP.require('request', function(request) {
    init();
});

function init() {
    // Get issue key from URL params
    const urlParams = new URLSearchParams(window.location.search);
    currentIssueKey = urlParams.get('issueKey') || '';
    
    // Load saved MCP URL
    loadConfig();
    
    // Setup event listeners
    setupEventListeners();
    
    // Show config if no URL is set
    if (!mcpUrl) {
        document.getElementById('config-section').style.display = 'block';
    }
}

function setupEventListeners() {
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-button');
    const connectButton = document.getElementById('connect-button');
    const mcpUrlInput = document.getElementById('mcp-url');
    
    // Send message on Enter or button click
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    sendButton.addEventListener('click', sendMessage);
    connectButton.addEventListener('click', connectToMCP);
    
    // Show config on header click if admin
    document.getElementById('chat-header').addEventListener('dblclick', () => {
        const configSection = document.getElementById('config-section');
        configSection.style.display = configSection.style.display === 'none' ? 'block' : 'none';
    });
}

function loadConfig() {
    // Try to load from localStorage first
    const savedUrl = localStorage.getItem('mcp-agent-url');
    if (savedUrl) {
        mcpUrl = savedUrl;
        document.getElementById('mcp-url').value = savedUrl;
        testConnection();
    }
}

async function connectToMCP() {
    const urlInput = document.getElementById('mcp-url');
    const newUrl = urlInput.value.trim();
    
    if (!newUrl) {
        alert('Please enter a valid MCP agent URL');
        return;
    }
    
    mcpUrl = newUrl;
    localStorage.setItem('mcp-agent-url', mcpUrl);
    
    await testConnection();
    
    if (connected) {
        document.getElementById('config-section').style.display = 'none';
        addMessage('system', 'Connected to MCP agent successfully!');
    }
}

async function testConnection() {
    const statusElement = document.getElementById('connection-status');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-button');
    
    try {
        // Test connection with a simple ping
        const response = await fetch(mcpUrl + '/health', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        
        if (response.ok) {
            connected = true;
            statusElement.textContent = 'Connected';
            statusElement.classList.add('connected');
            chatInput.disabled = false;
            sendButton.disabled = false;
        } else {
            throw new Error('Connection failed');
        }
    } catch (error) {
        connected = false;
        statusElement.textContent = 'Disconnected';
        statusElement.classList.remove('connected');
        chatInput.disabled = true;
        sendButton.disabled = true;
        console.error('Connection test failed:', error);
    }
}

async function sendMessage() {
    const chatInput = document.getElementById('chat-input');
    const message = chatInput.value.trim();
    
    if (!message || !connected) return;
    
    // Add user message to chat
    addMessage('user', message);
    chatInput.value = '';
    
    // Show typing indicator
    const typingId = addMessage('ai', 'Thinking...');
    
    try {
        // Send to MCP agent
        const response = await fetch(mcpUrl + '/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                context: {
                    issueKey: currentIssueKey,
                    platform: 'jira'
                }
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to get response from MCP agent');
        }
        
        const data = await response.json();
        
        // Remove typing indicator and add actual response
        removeMessage(typingId);
        addMessage('ai', data.response || 'No response received');
        
    } catch (error) {
        removeMessage(typingId);
        addMessage('ai', 'Sorry, I encountered an error: ' + error.message);
        console.error('Chat error:', error);
    }
}

function addMessage(sender, content) {
    const messagesContainer = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    const messageId = 'msg-' + Date.now();
    
    messageDiv.id = messageId;
    messageDiv.className = `message ${sender}-message`;
    
    const contentDiv = document.createElement('div');
    contentDiv.textContent = content;
    
    const timeDiv = document.createElement('div');
    timeDiv.className = 'message-time';
    timeDiv.textContent = new Date().toLocaleTimeString();
    
    messageDiv.appendChild(contentDiv);
    messageDiv.appendChild(timeDiv);
    messagesContainer.appendChild(messageDiv);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    return messageId;
}

function removeMessage(messageId) {
    const messageElement = document.getElementById(messageId);
    if (messageElement) {
        messageElement.remove();
    }
}

// Handle Jira context
AP.require('context', function(context) {
    context.getToken(function(token) {
        // Store token if needed for API calls
        window.jiraToken = token;
    });
});